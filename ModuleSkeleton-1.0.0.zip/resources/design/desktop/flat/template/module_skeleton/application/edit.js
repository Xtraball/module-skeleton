/*global
 bindForms
 */
$(document).ready(function () {
    bindForms('#skeleton');
});
