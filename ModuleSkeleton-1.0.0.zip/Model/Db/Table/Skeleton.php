<?php

/**
 * Class ModuleSkeleton_Model_Db_Table_Skeleton
 */
class ModuleSkeleton_Model_Db_Table_Skeleton extends Core_Model_Db_Table
{

    /**
     * @var string
     */
    protected $_name = "module_skeleton";

    /**
     * @var string
     */
    protected $_primary = "skeleton_id";

}