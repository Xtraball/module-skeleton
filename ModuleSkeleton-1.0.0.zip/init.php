<?php

/**
 * @param $bootstrap
 */
$init = function ($bootstrap) {

};